#!/bin/bash

########################################
# DPKG REPORT Instrunctions
########################################

# Implementations
########################################
# Log file: -> file name
# Total entries Log
# Install entries
# Upgrade entries
# Remove entries
# Most recent activity
#######################################

# command: dpkg-report.sh `filename` `n`
# n -> select option


# Notes
# Due tuesday 13th
# each should be a separate function and including a main function
# Inclide error checks:
#			files does not exist
#			file not readable
#			incorrect number of command line arguments
#			etc...
# Create a new subdirectory: Assignment04/dpkg-report.sh
# Copy dpkg.log.1 to subdirectory
# Submit a zipfile

########################################################################
#  program code


####################################################################
# Log File
####################################################################

function log_file(){
	echo ${args[0]}
}

####################################################################
# Total Entries Log
####################################################################

function total_entries(){
	grep "" ${args[0]}
}

####################################################################
# Installed Entries
####################################################################

function installed_entries(){
	grep "installed" ${args[0]}
}

####################################################################
# Upgraded Entries
####################################################################

function upgraded_entries(){
	grep "upgrade" ${args[0]}
}

####################################################################
# Removed Entries
####################################################################

function removed_entries(){
	grep "remove" ${args[0]}
}

####################################################################
# Most Recent Activity
####################################################################

function recent_activity(){
	grep "" ${args[0]} | tail
}

####################################################################
# display function - dipslay the program options
####################################################################

function print_menu(){
	clear
        echo "****************************************************"
        echo "*               Select Option 1-5                  *"
        echo "* 1. Log File                                      *"
        echo "* 2. Total Entries Log                             *"
        echo "* 3. Installed Entries                             *"
        echo "* 4. Upgraded Entries                              *"
        echo "* 5. Removed Entries                               *"
        echo "* 6. Most Recent Activity                          *"
        echo "* 7. Exit                                          *"
        echo "****************************************************"
}


#######################################################################
# checks - handles error checks
#######################################################################

function read_input(){
	args=""
	#checks
	#while loop with 3 conditions, keeps looping until all the conditions are met
	while true; do

		#prompts the user to enter a file and select an option
		# -r -> Raw -p -> print
		# -a -> stoles the arguments from the user as an array
		read -r -p "Enter a file and select an option: " -a args

                if [[ ${#args[@]} -ne 2 || ${#args[@]} -eq 1 && ${args[0]} -eq 7 ]]; then #checks if the user enters ! two arguments
		    if [[ ${#args[0]} -eq 1 && ${args[0]} -eq 7 ]]; then
		        echo "Exiting..."
			exit 1
		    else
		        echo ""
                        echo "invalid number of arguments: "
                        echo "Usage: <file_name> <n>"
			echo "7 to exit"
		        echo ""
		    fi
	    	    continue #re-run the loop is condition is not met, skipping the break statement at the end
		fi

                if [[ ! -f ${args[0]} ]]; then #checks if the first argument is ! a file
		    echo ""
                    echo "Argument one must be a file: "
                    echo "Usage: <file_name> <n> "
		    echo ""
                    continue #re-run the loop is condition is not met, skipping the break statement at the end
                fi

                if [[ ! (${args[1]} =~ ^[1-7]$) ]]; then #checks if the second argument is ! a number 1-7
		    echo ""
                    echo "Argument two must be a number [1-7]: "
                    echo "Usage: <file_name> <n> "
		    echo ""
                   continue #re-run the loop is condition is not met, skipping the break statement at the end
                fi
		break #all conditions are met, exits while loop
	done


	#checks the second argument, which is the selected menu options
	#and calls the apropriate function.

	if [[ ${args[1]}  -eq 1 ]]; then
		log_file
	elif [[ ${args[1]}  -eq 2 ]]; then
		total_entries
	elif [[ ${args[1]}  -eq 3 ]]; then
		installed_entries
	elif [[ ${args[1]}  -eq 4 ]]; then
		upgraded_entries
	elif [[ ${args[1]}  -eq 5 ]]; then
		removed_entries
	elif [[ ${args[1]}  -eq 6 ]]; then
		recent_activity
	elif [[ ${args[1]}  -eq 7 ]]; then
		echo "Exiting...."
		exit 1
	fi
}

#############################################################
# Main Function
#############################################################

function main(){
	print_menu
	read_input
}

main


