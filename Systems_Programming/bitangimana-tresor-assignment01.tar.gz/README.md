# Tresor Bitangimana
### sep 12/2026


# Linux distribution
PRETTY_NAME="Ubuntu 24.04.4 LTS"
NAME="Ubuntu"
VERSION_ID="24.04"
VERSION="24.04.4 LTS (Noble Numbat)"
VERSION_CODENAME=noble
ID=ubuntu
ID_LIKE=debian
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
UBUNTU_CODENAME=noble
LOGO=ubuntu-logo

## Extraction instructions

desktop:
1. download file to desktop
2. double click to extract compress file to regular folder 
3. Open de-compressed folder

Directory:
1. Navigate to directory
2. execute `tar -xzvf bitangimana-tresor-assignment01.tar.gz`

files will be extracted after running the command
